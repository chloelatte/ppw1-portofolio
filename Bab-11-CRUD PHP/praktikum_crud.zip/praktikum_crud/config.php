<?php

session_start();

$conn = mysqli_connect(
    "localhost",
    "root",
    "",
    "praktikum_crud"
);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

/* CEK LOGIN */

function requireLogin()
{
    if (!isset($_SESSION['login'])) {

        header("Location: login.php");
        exit();
    }
}

/* UPLOAD FOTO */

function uploadFile($file)
{
    $target_dir = "uploads/mahasiswa/";

    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    $allowed = ['jpg', 'jpeg', 'png', 'gif'];

    $filename = $file['name'];
    $tmp = $file['tmp_name'];
    $size = $file['size'];
    $error = $file['error'];

    if ($error !== 0) {
        return [
            'success' => false,
            'message' => 'Upload gagal'
        ];
    }

    $ext = strtolower(
        pathinfo($filename, PATHINFO_EXTENSION)
    );

    if (!in_array($ext, $allowed)) {

        return [
            'success' => false,
            'message' => 'Format file tidak didukung'
        ];
    }

    if ($size > 5 * 1024 * 1024) {

        return [
            'success' => false,
            'message' => 'Ukuran file maksimal 5MB'
        ];
    }

    $newname =
        uniqid() . "." . $ext;

    $destination =
        $target_dir . $newname;

    if (move_uploaded_file($tmp, $destination)) {

        return [
            'success' => true,
            'filename' => $newname
        ];
    }

    return [
        'success' => false,
        'message' => 'Gagal upload file'
    ];
}

/* HAPUS FOTO */

function deleteFile($filename)
{
    $path = "uploads/mahasiswa/" . $filename;

    if (file_exists($path)) {
        unlink($path);
    }
}
?>