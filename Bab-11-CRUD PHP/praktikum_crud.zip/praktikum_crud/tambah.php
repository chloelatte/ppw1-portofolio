<?php
include_once("config.php");
requireLogin();

$errors = [];

if(isset($_POST['submit'])){

    $nim = mysqli_real_escape_string($conn, $_POST['nim']);
    $nama = mysqli_real_escape_string($conn, $_POST['nama']);
    $jurusan = mysqli_real_escape_string($conn, $_POST['jurusan']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $alamat = mysqli_real_escape_string($conn, $_POST['alamat']);

    $foto_filename = null;

    /* VALIDASI */

    if(empty($nim)){
        $errors[] = "NIM tidak boleh kosong";
    }

    if(!is_numeric($nim)){
        $errors[] = "NIM hanya boleh berisi angka";
    }

    if(strlen($nim) < 8 || strlen($nim) > 12){
        $errors[] = "Panjang NIM harus 8-12 digit";
    }

    if(empty($nama)){
        $errors[] = "Nama tidak boleh kosong";
    }

    if(empty($jurusan)){
        $errors[] = "Jurusan tidak boleh kosong";
    }

    if(empty($email)){
        $errors[] = "Email tidak boleh kosong";
    }

    elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)){
        $errors[] = "Format email tidak valid";
    }

    /* CEK NIM */

    $check = mysqli_query(
        $conn,
        "SELECT nim FROM mahasiswa
        WHERE nim='$nim'"
    );

    if(mysqli_num_rows($check) > 0){
        $errors[] = "NIM sudah terdaftar";
    }

    /* UPLOAD FOTO */

    if(!empty($_FILES['foto']['name'])){

        $upload = uploadFile($_FILES['foto']);

        if($upload['success']){

            $foto_filename =
            $upload['filename'];

        }else{

            $errors[] =
            $upload['message'];
        }
    }

    /* INSERT */

    if(empty($errors)){

        $foto_sql =
        $foto_filename
        ? "'$foto_filename'"
        : "NULL";

        $sql = "INSERT INTO mahasiswa
        (
            nim,
            nama,
            jurusan,
            email,
            alamat,
            foto
        )
        VALUES
        (
            '$nim',
            '$nama',
            '$jurusan',
            '$email',
            '$alamat',
            $foto_sql
        )";

        if(mysqli_query($conn, $sql)){

            $_SESSION['message'] =
            "Data berhasil ditambahkan";

            header("Location:index.php");
            exit();

        }else{

            $errors[] =
            mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html>

<head>

<title>Tambah Mahasiswa</title>

<link rel="stylesheet"
href="style.css">

</head>

<body>

<div class="form-container">

    <div class="form-title">
        Tambah Mahasiswa
    </div>

    <?php if(!empty($errors)) : ?>

        <div class="alert error-alert">

            <?php foreach($errors as $error) : ?>

                <div>
                    • <?= $error; ?>
                </div>

            <?php endforeach; ?>

        </div>

    <?php endif; ?>

    <form
    action=""
    method="POST"
    enctype="multipart/form-data">

        <div class="form-group">

            <label>Foto Profil</label>

            <input
            type="file"
            name="foto"
            accept="image/*">

        </div>

        <div class="form-group">

            <label>NIM</label>

            <input
            type="text"
            name="nim"
            required>

        </div>

        <div class="form-group">

            <label>Nama</label>

            <input
            type="text"
            name="nama"
            required>

        </div>

        <div class="form-group">

            <label>Jurusan</label>

            <input
            type="text"
            name="jurusan"
            required>

        </div>

        <div class="form-group">

            <label>Email</label>

            <input
            type="email"
            name="email"
            required>

        </div>

        <div class="form-group">

            <label>Alamat</label>

            <textarea
            name="alamat"></textarea>

        </div>

        <button
        type="submit"
        name="submit"
        class="submit-btn">

            Simpan Data

        </button>

    </form>

</div>

</body>
</html>