<?php
include_once("config.php");

$errors = [];

if(isset($_POST['login'])){

    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    $query = mysqli_query($conn,

    "SELECT * FROM users
    WHERE username='$username'");

    if(mysqli_num_rows($query) > 0){

        $user = mysqli_fetch_assoc($query);

        /* SUPPORT HASH + PLAINTEXT */

        $valid = false;

        // password hash

        if(password_verify(
            $password,
            $user['password']
        )){
            $valid = true;
        }

        // plaintext lama

        if($password === $user['password']){
            $valid = true;
        }

        if($valid){

            $_SESSION['login'] = true;

            $_SESSION['user_id'] =
            $user['id'];

            $_SESSION['username'] =
            $user['username'];

            header("Location:index.php");
            exit();
        }
    }

    $errors[] =
    "Username atau password salah";
}
?>

<!DOCTYPE html>
<html>
<head>

<title>Login</title>

<link rel="stylesheet"
href="style.css">

</head>

<body>

<div class="auth-card">

    <div class="form-title">

        Login

    </div>

    <?php if(!empty($errors)) : ?>

        <div class="alert">

            <?php foreach($errors as $e){

                echo $e . "<br>";

            } ?>

        </div>

    <?php endif; ?>

    <form method="POST">

        <div class="form-group">

            <label>Username</label>

            <input type="text"
                   name="username"
                   required>

        </div>

        <div class="form-group">

            <label>Password</label>

            <input type="password"
                   name="password"
                   required>

        </div>

        <button type="submit"
                name="login"
                class="submit-btn">

            Login

        </button>

    </form>

    <div class="auth-link">

        Belum punya akun?

        <a href="register.php">

            Register

        </a>

    </div>

</div>

</body>
</html>