<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Profil Diri</title>

    <style>
        body{
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 30px;
        }

        table{
            border-collapse: collapse;
            width: 500px;
            background-color: white;
        }

        th, td{
            border: 1px solid #999;
            padding: 12px;
        }

        th{
            background-color: #dbeafe;
        }

        h2{
            color: #333;
        }
    </style>
</head>
<body>

<?php
$nama = "Kaori Manurung";
$nim = "25/556977/SV/26072";
$prodi = "Teknologi Rekayasa Perangkat Lunak";
$asalKota = "Balige";
?>

<h2>Profil Mahasiswa</h2>

<table>
    <tr>
        <th>Data</th>
        <th>Isi</th>
    </tr>

    <tr>
        <td>Nama</td>
        <td><?php echo $nama; ?></td>
    </tr>

    <tr>
        <td>NIM</td>
        <td><?php echo $nim; ?></td>
    </tr>

    <tr>
        <td>Program Studi</td>
        <td><?php echo $prodi; ?></td>
    </tr>

    <tr>
        <td>Asal Kota</td>
        <td><?php echo $asalKota; ?></td>
    </tr>
</table>

</body>
</html>