// ================= EXTERNAL JAVASCRIPT =================

// console.log() dari EXTERNAL
console.log("[EXTERNAL] File script.js berhasil terhubung");
// innerHTML dari EXTERNAL
document.getElementById("hasilExternal").innerHTML = `

  <div style="
    background:#eef1ff;
    border-left:5px solid #5b5be0;
    padding:12px;
  ">
    <b>[EXTERNAL]</b>
    Output ini ditampilkan menggunakan innerHTML
    dari file script.js
  </div>
`;