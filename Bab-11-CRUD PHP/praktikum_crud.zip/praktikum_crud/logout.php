<?php
include_once("config.php");

$errors = [];

if(isset($_POST['register'])){

    $email = trim($_POST['email']);
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $confirm = trim($_POST['confirm']);

    /* VALIDASI */

    if(empty($email)){
        $errors[] = "Email wajib diisi";
    }

    if(!filter_var($email,
        FILTER_VALIDATE_EMAIL)){

        $errors[] = "Format email tidak valid";
    }

    if(empty($username)){
        $errors[] = "Username wajib diisi";
    }

    if(strlen($password) < 6){
        $errors[] =
        "Password minimal 6 karakter";
    }

    if($password !== $confirm){
        $errors[] =
        "Konfirmasi password tidak cocok";
    }

    /* CEK USERNAME */

    $check = mysqli_query($conn,
    "SELECT * FROM users
    WHERE username='$username'");

    if(mysqli_num_rows($check) > 0){

        $errors[] =
        "Username sudah digunakan";
    }

    /* INSERT USER */

    if(empty($errors)){

        $hash = password_hash($password,
        PASSWORD_DEFAULT);

        mysqli_query($conn,
        "INSERT INTO users
        (email,username,password)

        VALUES

        ('$email','$username','$hash')");

        $_SESSION['message'] =
        "Registrasi berhasil";

        header("Location: login.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html>
<head>

<title>Register</title>

<link rel="stylesheet" href="style.css">

</head>

<body>

<div class="auth-card">

    <div class="form-title">

        Register

    </div>

    <?php if(!empty($errors)) : ?>

        <div class="alert">

            <?php foreach($errors as $e){

                echo $e . "<br>";

            } ?>

        </div>

    <?php endif; ?>

    <form method="POST">

        <div class="form-group">

            <label>Email</label>

            <input type="email"
                   name="email"
                   required>

        </div>

        <div class="form-group">

            <label>Username</label>

            <input type="text"
                   name="username"
                   required>

        </div>

        <div class="form-group">

            <label>Password</label>

            <input type="password"
                   name="password"
                   required>

        </div>

        <div class="form-group">

            <label>Konfirmasi Password</label>

            <input type="password"
                   name="confirm"
                   required>

        </div>

        <button type="submit"
                name="register"
                class="submit-btn">

            Register

        </button>

    </form>

    <div class="auth-link">

        Sudah punya akun?

        <a href="login.php">

            Login

        </a>

    </div>

</div>

</body>
</html>