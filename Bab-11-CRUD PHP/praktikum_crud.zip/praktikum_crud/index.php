<?php
include_once("config.php");
requireLogin();

$search = "";

if(isset($_GET['search'])){

    $search = mysqli_real_escape_string(
        $conn,
        $_GET['search']
    );
}

$query = mysqli_query(
    $conn,
    "SELECT * FROM mahasiswa
    WHERE
    nim LIKE '%$search%'
    OR nama LIKE '%$search%'
    OR jurusan LIKE '%$search%'
    ORDER BY id DESC"
);
?>

<!DOCTYPE html>
<html>

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>Data Mahasiswa</title>

<link rel="stylesheet"
href="style.css">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

</head>

<body>

<div class="container">

    <!-- TOP BAR -->

    <div class="top-bar">

        <h1 class="page-title">

            Data Mahasiswa

        </h1>

        <div class="top-actions">

            <a href="tambah.php"
            class="add-full-btn">

                <i class="fa-solid fa-plus"></i>

                Tambah Mahasiswa

            </a>

            <a href="logout.php"
            class="main-btn logout-btn">

                <i class="fa-solid fa-right-from-bracket"></i>

            </a>

        </div>

    </div>

    <!-- ALERT -->

    <?php if(isset($_SESSION['message'])) : ?>

        <div class="alert success-alert">

            <?= $_SESSION['message']; ?>

        </div>

        <?php unset($_SESSION['message']); ?>

    <?php endif; ?>

    <!-- SEARCH -->

    <form
    method="GET"
    class="search-bar">

        <input
        type="text"
        name="search"
        placeholder="Cari mahasiswa..."
        value="<?= $search; ?>">

        <button type="submit">

            <i class="fa-solid fa-magnifying-glass"></i>

        </button>

    </form>

    <!-- TABLE -->

    <div class="table-card">

        <table>

            <thead>

                <tr>

                    <th>Foto</th>
                    <th>NIM</th>
                    <th>Mahasiswa</th>
                    <th>Email</th>
                    <th>Alamat</th>
                    <th>Tanggal Daftar</th>
                    <th>Aksi</th>

                </tr>

            </thead>

            <tbody>

            <?php if(mysqli_num_rows($query) > 0) : ?>

                <?php while($row = mysqli_fetch_assoc($query)) : ?>

                    <tr>

                        <!-- FOTO -->

                        <td>

                            <?php if($row['foto']) : ?>

                                <img
                                src="uploads/mahasiswa/<?= $row['foto']; ?>"
                                class="photo">

                            <?php else : ?>

                                <div class="no-photo">

                                    N/A

                                </div>

                            <?php endif; ?>

                        </td>

                        <!-- NIM -->

                        <td>

                            <?= $row['nim']; ?>

                        </td>

                        <!-- NAMA + JURUSAN -->

                        <td>

                            <div class="student-name">

                                <?= $row['nama']; ?>

                            </div>

                            <div class="student-major">

                                <?= $row['jurusan']; ?>

                            </div>

                        </td>

                        <!-- EMAIL -->

                        <td>

                            <?= $row['email']; ?>

                        </td>

                        <!-- ALAMAT -->

                        <td class="alamat-column">

                            <?= !empty($row['alamat'])
                            ? $row['alamat']
                            : '-'; ?>

                        </td>

                        <!-- CREATED AT -->

                        <td>

                            <?= $row['created_at']; ?>

                        </td>

                        <!-- AKSI -->

                        <td>

                            <div class="action-buttons">

                                <a href="detail.php?id=<?= $row['id']; ?>"
                                class="icon-btn detail-btn"
                                title="Detail">

                                    <i class="fa-solid fa-eye"></i>

                                </a>

                                <a href="edit.php?id=<?= $row['id']; ?>"
                                class="icon-btn edit-btn"
                                title="Edit">

                                    <i class="fa-solid fa-pen"></i>

                                </a>

                                <a href="hapus.php?id=<?= $row['id']; ?>"
                                class="icon-btn delete-btn"
                                title="Hapus"
                                onclick="return confirm('Hapus data mahasiswa ini?')">

                                    <i class="fa-solid fa-trash"></i>

                                </a>

                            </div>

                        </td>

                    </tr>

                <?php endwhile; ?>

            <?php else : ?>

                <tr>

                    <td colspan="7"
                    class="empty-data">

                        Data mahasiswa tidak ditemukan

                    </td>

                </tr>

            <?php endif; ?>

            </tbody>

        </table>

    </div>

</div>

</body>
</html>