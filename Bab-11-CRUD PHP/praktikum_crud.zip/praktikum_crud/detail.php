<?php

include_once("config.php");

requireLogin();

/* CEK ID */

if(!isset($_GET['id'])){

    header("Location: index.php");
    exit();
}

$id = $_GET['id'];

/* AMBIL DATA */

$query = mysqli_query(
    $conn,
    "SELECT * FROM mahasiswa WHERE id='$id'"
);

$data = mysqli_fetch_assoc($query);

/* JIKA DATA TIDAK ADA */

if(!$data){

    header("Location: index.php");
    exit();
}

?>

<!DOCTYPE html>
<html>

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>Detail Mahasiswa</title>

<link rel="stylesheet"
href="style.css">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

</head>

<body>

<div class="detail-card">

    <h1 class="form-title">

        Detail Mahasiswa

    </h1>

    <!-- FOTO -->

    <div class="detail-photo-wrapper">

        <?php if($data['foto']) : ?>

            <img
            src="uploads/mahasiswa/<?= $data['foto']; ?>"
            class="detail-photo">

        <?php else : ?>

            <div class="no-photo"
            style="
            width:220px;
            height:220px;
            font-size:24px;
            ">

                N/A

            </div>

        <?php endif; ?>

    </div>

    <!-- INFO -->

    <div class="info-group">

        <div class="info-item">

            <div class="label">

                NIM

            </div>

            <div class="value">

                <?= $data['nim']; ?>

            </div>

        </div>

        <div class="info-item">

            <div class="label">

                Nama

            </div>

            <div class="value">

                <?= $data['nama']; ?>

            </div>

        </div>

        <div class="info-item">

            <div class="label">

                Jurusan

            </div>

            <div class="value">

                <?= $data['jurusan']; ?>

            </div>

        </div>

        <div class="info-item">

            <div class="label">

                Email

            </div>

            <div class="value">

                <?= $data['email']; ?>

            </div>

        </div>

        <div class="info-item">

            <div class="label">

                Alamat

            </div>

            <div class="value">

                <?= $data['alamat']; ?>

            </div>

        </div>

        <div class="info-item">

            <div class="label">

                Tanggal Daftar

            </div>

            <div class="value">

                <?= $data['created_at']; ?>

            </div>

        </div>

    </div>

    <!-- BUTTON -->

    <div class="button-group">

        <a href="index.php"
        class="main-btn back-btn">

            <i class="fa-solid fa-arrow-left"></i>

            Kembali

        </a>

        <a href="edit.php?id=<?= $data['id']; ?>"
        class="main-btn edit2-btn">

            <i class="fa-solid fa-pen"></i>

            Edit Data

        </a>

    </div>

</div>

</body>
</html>