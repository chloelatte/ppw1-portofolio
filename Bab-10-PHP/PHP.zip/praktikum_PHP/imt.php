<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kalkulator IMT</title>

    <style>
        body{
            font-family: Arial, sans-serif;
            background-color: #f0f8ff;
            padding: 30px;
        }

        .container{
            background: white;
            padding: 20px;
            width: 400px;
            border-radius: 10px;
        }

        input{
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            margin-bottom: 15px;
        }

        button{
            padding: 10px 15px;
            background-color: #60a5fa;
            border: none;
            color: white;
            border-radius: 5px;
            cursor: pointer;
        }

        h2{
            color: #333;
        }
    </style>
</head>
<body>

<div class="container">

<h2>Kalkulator IMT</h2>

<form method="POST">

    <label>Berat Badan (kg)</label>
    <input type="number" name="berat" required>

    <label>Tinggi Badan (cm)</label>
    <input type="number" name="tinggi" required>

    <button type="submit">Hitung IMT</button>

</form>

<?php

function hitungIMT($berat, $tinggi){

    $tinggiMeter = $tinggi / 100;

    $imt = $berat / ($tinggiMeter * $tinggiMeter);

    if($imt < 18.5){
        $kategori = "Kurus";
    }
    elseif($imt >= 18.5 && $imt <= 24.9){
        $kategori = "Normal";
    }
    elseif($imt >= 25 && $imt <= 29.9){
        $kategori = "Gemuk";
    }
    else{
        $kategori = "Obesitas";
    }

    return [
        "imt" => round($imt, 2),
        "kategori" => $kategori
    ];
}

if($_SERVER["REQUEST_METHOD"] == "POST"){

    $berat = $_POST['berat'];
    $tinggi = $_POST['tinggi'];

    $hasil = hitungIMT($berat, $tinggi);

    echo "<hr>";
    echo "<h3>Hasil Perhitungan</h3>";

    echo "<p><b>Berat Badan:</b> $berat kg</p>";
    echo "<p><b>Tinggi Badan:</b> $tinggi cm</p>";

    echo "<p><b>Nilai IMT:</b> " . $hasil['imt'] . "</p>";

    echo "<p><b>Kategori:</b> " . $hasil['kategori'] . "</p>";
}

?>

</div>

</body>
</html>