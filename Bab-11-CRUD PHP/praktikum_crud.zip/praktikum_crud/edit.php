<?php
include_once("config.php");
requireLogin();

if(!isset($_GET['id'])){
    header("Location:index.php");
    exit();
}

$id = (int)$_GET['id'];

$result = mysqli_query(
    $conn,
    "SELECT * FROM mahasiswa
    WHERE id=$id"
);

$data = mysqli_fetch_assoc($result);

$current_foto = $data['foto'];

$errors = [];

if(isset($_POST['update'])){

    $nim = mysqli_real_escape_string($conn, $_POST['nim']);
    $nama = mysqli_real_escape_string($conn, $_POST['nama']);
    $jurusan = mysqli_real_escape_string($conn, $_POST['jurusan']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $alamat = mysqli_real_escape_string($conn, $_POST['alamat']);

    /* VALIDASI NIM */

    if(!is_numeric($nim)){
        $errors[] =
        "NIM hanya boleh angka";
    }

    if(strlen($nim) < 8 ||
       strlen($nim) > 12){

        $errors[] =
        "Panjang NIM harus 8-12 digit";
    }

    $foto_filename = $current_foto;

    /* GANTI FOTO */

    if(!empty($_FILES['foto']['name'])){

        $upload = uploadFile($_FILES['foto']);

        if($upload['success']){

            if($current_foto){
                deleteFile($current_foto);
            }

            $foto_filename =
            $upload['filename'];

        }else{

            $errors[] =
            $upload['message'];
        }
    }

    /* UPDATE */

    if(empty($errors)){

        $foto_sql =
        $foto_filename
        ? "'$foto_filename'"
        : "NULL";

        $sql = "UPDATE mahasiswa SET

        nim='$nim',
        nama='$nama',
        jurusan='$jurusan',
        email='$email',
        alamat='$alamat',
        foto=$foto_sql

        WHERE id=$id";

        if(mysqli_query($conn, $sql)){

            $_SESSION['message'] =
            "Data berhasil diupdate";

            header("Location:index.php");
            exit();

        }else{

            $errors[] =
            mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html>

<head>

<title>Edit Mahasiswa</title>

<link rel="stylesheet"
href="style.css">

</head>

<body>

<div class="form-container">

    <div class="form-title">

        Edit Mahasiswa

    </div>

    <?php if(!empty($errors)) : ?>

        <div class="alert error-alert">

            <?php foreach($errors as $error) : ?>

                <div>
                    • <?= $error; ?>
                </div>

            <?php endforeach; ?>

        </div>

    <?php endif; ?>

    <form
    action=""
    method="POST"
    enctype="multipart/form-data">

        <div class="current-photo-wrapper">

            <?php if($data['foto']) : ?>

                <img
                src="uploads/mahasiswa/<?= $data['foto']; ?>"
                class="current-photo">

            <?php else : ?>

                <div class="no-photo">

                    N/A

                </div>

            <?php endif; ?>

        </div>

        <div class="form-group">

            <label>Ganti Foto</label>

            <input
            type="file"
            name="foto"
            accept="image/*">

        </div>

        <div class="form-group">

            <label>NIM</label>

            <input
            type="text"
            name="nim"
            value="<?= $data['nim']; ?>"
            required>

        </div>

        <div class="form-group">

            <label>Nama</label>

            <input
            type="text"
            name="nama"
            value="<?= $data['nama']; ?>"
            required>

        </div>

        <div class="form-group">

            <label>Jurusan</label>

            <input
            type="text"
            name="jurusan"
            value="<?= $data['jurusan']; ?>"
            required>

        </div>

        <div class="form-group">

            <label>Email</label>

            <input
            type="email"
            name="email"
            value="<?= $data['email']; ?>"
            required>

        </div>

        <div class="form-group">

            <label>Alamat</label>

            <textarea
            name="alamat"><?= $data['alamat']; ?></textarea>

        </div>

        <button
        type="submit"
        name="update"
        class="submit-btn">

            Update Data

        </button>

    </form>

</div>

</body>
</html>