<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tanggal dan Sisa Hari</title>

    <style>
        body{
            font-family: Arial, sans-serif;
            background-color: #fff8dc;
            padding: 30px;
        }

        .box{
            background: white;
            padding: 20px;
            width: 450px;
            border-radius: 10px;
        }

        h2{
            color: #444;
        }
    </style>
</head>
<body>

<div class="box">

<?php

date_default_timezone_set("Asia/Jakarta");

$bulan = date("F");
$hariIni = date("d");

$totalHari = date("t");

$sisaHari = $totalHari - $hariIni;

?>

<h2>Informasi Bulan Sekarang</h2>

<p><b>Bulan Sekarang:</b> <?php echo $bulan; ?></p>

<p><b>Tanggal Hari Ini:</b> <?php echo date("d-m-Y"); ?></p>

<p><b>Total Hari Bulan Ini:</b> <?php echo $totalHari; ?></p>

<p><b>Sisa Hari Bulan Ini:</b> <?php echo $sisaHari; ?> hari</p>

</div>

</body>
</html>